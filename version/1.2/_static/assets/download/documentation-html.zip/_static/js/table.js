$(document).ready(function () {
  $("table.datatable").DataTable();
});
